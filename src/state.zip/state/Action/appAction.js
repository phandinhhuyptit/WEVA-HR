import * as appContant from '../Contant/appContant';

export const toogleCollapsed = () => {
    return {

        type: appContant.changeToggleCollapsed

    }
}