import * as effectAction from '../Contant/effectContant';


export const turnOnOrOffForFormOfferAndBackgroundBody = () =>{      
        return {

            type :   effectAction.turnOnOrOffBackgroundBodyAndFormOffer
        }
}